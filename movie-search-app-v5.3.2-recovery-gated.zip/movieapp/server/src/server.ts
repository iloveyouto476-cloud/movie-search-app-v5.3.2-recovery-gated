import "dotenv/config";
import cors from "cors";
import crypto from "node:crypto";
import dns from "node:dns/promises";
import net from "node:net";
import express from "express";
import { createClient } from "@supabase/supabase-js";

const app = express();
const port = Number(process.env.PORT ?? 3001);
const supabaseUrl = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const proxySecret = process.env.PROXY_SIGNING_SECRET ?? serviceKey ?? crypto.randomBytes(32).toString("hex");
const allowedOrigins = new Set((process.env.ALLOWED_ORIGINS ?? "http://localhost:5173").split(",").map((x) => x.trim()).filter(Boolean));
const allowedHosts = new Set((process.env.ALLOWED_STREAM_HOSTS ?? "").split(",").map((x) => normalizeHost(x)).filter(Boolean));
const blockedHosts = new Set((process.env.BLOCKED_STREAM_HOSTS ?? "").split(",").map((x) => normalizeHost(x)).filter(Boolean));
const MAX_HLS_MANIFEST_BYTES = 4 * 1024 * 1024;
const MAX_REDIRECTS = 5;
const PROXY_TOKEN_TTL_MS = 10 * 60 * 1000;
const supabase = supabaseUrl && serviceKey ? createClient(supabaseUrl, serviceKey) : null;

app.disable("x-powered-by");
app.use(cors({ origin: (origin, callback) => {
  if (!origin || allowedOrigins.has(origin)) return callback(null, true);
  return callback(new Error("Origin not allowed"));
}}));
app.use(express.json({ limit: "32kb" }));
app.use((_, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  next();
});

function normalizeHost(value: string): string {
  return value.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/$/, "").replace(/^www\./, "");
}

function isPrivateIp(address: string): boolean {
  if (net.isIPv4(address)) {
    const [a, b, c] = address.split(".").map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127) || (a === 192 && b === 0 && c === 0) ||
      (a === 198 && b >= 18 && b <= 19) || a >= 224;
  }
  if (net.isIPv6(address)) {
    const normalized = address.toLowerCase();
    if (normalized.startsWith("::ffff:")) {
      const mapped = normalized.slice(7);
      if (net.isIPv4(mapped)) return isPrivateIp(mapped);
    }
    return normalized === "::1" || normalized === "::" || normalized.startsWith("fc") ||
      normalized.startsWith("fd") || normalized.startsWith("fe80:") || normalized.startsWith("ff");
  }
  return true;
}

function approvedUrl(raw: string): URL | null {
  try {
    if (!raw || raw.length > 4096) return null;
    const u = new URL(raw);
    const host = normalizeHost(u.hostname);
    const port = u.port || (u.protocol === "https:" ? "443" : "80");
    if (!(["http:", "https:"].includes(u.protocol)) || !(["80", "443"].includes(port))) return null;
    if (u.username || u.password || blockedHosts.has(host)) return null;
    if (allowedHosts.size === 0 || !allowedHosts.has(host)) return null;
    return u;
  } catch { return null; }
}

async function resolvePublicHost(host: string): Promise<boolean> {
  if (net.isIP(host)) return !isPrivateIp(host);
  const addresses = await dns.lookup(host, { all: true, verbatim: true });
  return addresses.length > 0 && addresses.every(({ address }) => !isPrivateIp(address));
}

async function safeUrl(raw: string): Promise<boolean> {
  try {
    const u = approvedUrl(raw);
    return !!u && await resolvePublicHost(u.hostname);
  } catch { return false; }
}

async function fetchApproved(raw: string, init: RequestInit = {}): Promise<{ response: Response; url: string }> {
  let current = raw;
  for (let redirects = 0; redirects <= MAX_REDIRECTS; redirects++) {
    if (!(await safeUrl(current))) throw new Error("Stream host is not approved.");
    const response = await fetch(current, { ...init, redirect: "manual" });
    if (![301, 302, 303, 307, 308].includes(response.status)) return { response, url: current };
    const location = response.headers.get("location");
    if (!location) throw new Error("Upstream redirect has no location.");
    const next = new URL(location, current).toString();
    if (!(await safeUrl(next))) throw new Error("Upstream redirected to a non-approved host.");
    current = next;
  }
  throw new Error("Too many upstream redirects.");
}

async function checkSource(raw: string) {
  if (!(await safeUrl(raw))) return { ok: false, error: "Stream host is not approved." };
  try {
    let result = await fetchApproved(raw, { method: "HEAD", signal: AbortSignal.timeout(8000) });
    if (!result.response.ok || !result.response.headers.get("content-type")) {
      result = await fetchApproved(raw, { method: "GET", headers: { Range: "bytes=0-1" }, signal: AbortSignal.timeout(8000) });
    }
    const response = result.response;
    const finalUrl = result.url;
    const contentType = response.headers.get("content-type")?.split(";", 1)[0].trim().toLowerCase();
    const clean = finalUrl.split("?", 1)[0].toLowerCase();
    const playable = response.ok && !!contentType && (contentType.startsWith("video/") ||
      contentType === "application/vnd.apple.mpegurl" || contentType === "application/x-mpegurl" ||
      clean.endsWith(".m3u8") || clean.endsWith(".mp4") || clean.endsWith(".webm") || clean.endsWith(".ogg"));
    return { ok: playable, status: response.status, contentType, finalUrl,
      error: playable ? undefined : "Source is reachable but does not appear to be playable media." };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "Source health check failed." };
  }
}

function playbackKind(raw: string, contentType?: string): "hls" | "video" {
  const clean = raw.split("?", 1)[0].toLowerCase();
  return clean.endsWith(".m3u8") || contentType?.includes("mpegurl") ? "hls" : "video";
}

function signProxyTarget(target: string): string {
  const expires = Date.now() + PROXY_TOKEN_TTL_MS;
  const payload = Buffer.from(JSON.stringify({ target, expires }), "utf8").toString("base64url");
  const signature = crypto.createHmac("sha256", proxySecret).update(payload).digest("base64url");
  return `${payload}.${signature}`;
}

function readProxyTarget(token: string): string | null {
  try {
    const [payload, signature] = token.split(".");
    if (!payload || !signature) return null;
    const expected = crypto.createHmac("sha256", proxySecret).update(payload).digest("base64url");
    if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
    const decoded = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as { target?: string; expires?: number };
    if (!decoded.target || !decoded.expires || decoded.expires < Date.now()) return null;
    return decoded.target;
  } catch { return null; }
}

function proxyUrl(base: string, target: string): string {
  return `${base}/api/stream/proxy?token=${encodeURIComponent(signProxyTarget(target))}`;
}

function rewriteHlsManifest(text: string, manifestUrl: string, proxyBase: string): string {
  const base = new URL(manifestUrl);
  const rewriteUri = (raw: string) => {
    try { return proxyUrl(proxyBase, new URL(raw, base).toString()); } catch { return raw; }
  };
  let output = text.replace(/URI=("[^"]+"|'[^']+')/g, (_match, quoted: string) => {
    const quote = quoted[0];
    return `URI=${quote}${rewriteUri(quoted.slice(1, -1))}${quote}`;
  });
  output = output.split(/(\r?\n)/).map((line, index) => {
    if (index % 2 === 1 || !line.trim() || line.startsWith("#")) return line;
    const leading = line.match(/^\s*/)?.[0] ?? "";
    const trailing = line.match(/\s*$/)?.[0] ?? "";
    return `${leading}${rewriteUri(line.trim())}${trailing}`;
  }).join("");
  return output;
}

async function movieById(id: string) {
  if (!supabase || !/^[A-Za-z0-9_-]{1,128}$/.test(id)) return null;
  const { data, error } = await supabase.from("movies")
    .select("id,title,original_title,year,rating,duration,genre,director,cast_members,plot,poster,backdrop,trailer_url,watch_url,source_id,quality,language,subtitles,is_safe,external_open")
    .eq("id", id).eq("is_safe", true).maybeSingle();
  if (error) throw error;
  return data;
}

async function providerIds() {
  if (!supabase) return [] as string[];
  const { data, error } = await supabase.from("movie_sources").select("id").eq("enabled", true).eq("search_enabled", true);
  if (error) throw error;
  return (data ?? []).map((p) => p.id as string);
}

async function playbackProviderIds() {
  if (!supabase) return [] as string[];
  const { data, error } = await supabase.from("movie_sources").select("id").eq("enabled", true).eq("external_watch_enabled", true);
  if (error) throw error;
  return (data ?? []).map((p) => p.id as string);
}

async function isPlaybackProviderAllowed(sourceId: string | null | undefined) {
  if (!sourceId) return false;
  const ids = await playbackProviderIds();
  return ids.includes(String(sourceId));
}

app.get("/api/health", (_, res) => res.json({ ok: true, service: "movie-search-api", version: "5.3.2" }));
app.get("/api/config", (_, res) => res.json({ player: { nativeVideo: true, directMp4: false, proxiedVideo: true, proxiedHls: true, signedProxy: true }, providerPolicy: { allowlistEnabled: allowedHosts.size > 0 } }));

app.get("/api/providers", async (_, res) => {
  if (!supabase) return res.status(503).json({ error: "Supabase server configuration missing." });
  const { data, error } = await supabase.from("movie_sources")
    .select("id,name,enabled,status,priority,trust_score,search_enabled,metadata_import_enabled,external_watch_enabled,iframe_enabled")
    .eq("enabled", true).order("priority", { ascending: false });
  if (error) return res.status(500).json({ error: "Provider lookup failed." });
  res.json(data ?? []);
});

app.get("/api/search", async (req, res) => {
  if (!supabase) return res.status(503).json({ error: "Supabase server configuration missing." });
  try {
    const q = String(req.query.q ?? "").trim().slice(0, 120);
    const ids = await providerIds();
    let request = supabase.from("movies")
      .select("id,title,original_title,year,rating,poster,backdrop,plot,genre,quality,language,source_id,is_safe")
      .eq("is_safe", true).limit(40);
    if (ids.length === 0) return res.json({ query: q, providers: 0, movies: [] });
    request = request.in("source_id", ids);
    if (q) {
      const escaped = q.replace(/\\/g, "\\\\").replace(/[%,_()*]/g, "\\$&");
      request = request.or(`title.ilike.%${escaped}%,original_title.ilike.%${escaped}%`);
    }
    const { data, error } = await request;
    if (error) return res.status(500).json({ error: "Movie search failed." });
    res.json({ query: q, providers: ids.length, movies: data ?? [] });
  } catch { res.status(500).json({ error: "Movie search failed." }); }
});

app.get("/api/movie/:id", async (req, res) => {
  if (!supabase) return res.status(503).json({ error: "Supabase server configuration missing." });
  try {
    const movie = await movieById(req.params.id);
    if (!movie) return res.status(404).json({ error: "Movie not found." });
    res.json(movie);
  } catch { res.status(500).json({ error: "Movie lookup failed." }); }
});

app.get("/api/providers/:providerId/search", async (req, res) => {
  if (!supabase) return res.status(503).json({ error: "Supabase server configuration missing." });
  const providerId = req.params.providerId;
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(providerId)) return res.status(400).json({ error: "Invalid provider id." });
  try {
    const playbackIds = await playbackProviderIds();
    const searchProviders = await providerIds();
    if (!searchProviders.includes(providerId)) return res.status(404).json({ error: "Provider not enabled for search." });
    const q = String(req.query.q ?? "").trim().slice(0, 120);
    let request = supabase.from("movies")
      .select("id,title,original_title,year,rating,poster,backdrop,plot,genre,quality,language,source_id,is_safe")
      .eq("is_safe", true).eq("source_id", providerId).limit(40);
    if (q) {
      const escaped = q.replace(/\\/g, "\\\\").replace(/[%,_()*]/g, "\\$&");
      request = request.or(`title.ilike.%${escaped}%,original_title.ilike.%${escaped}%`);
    }
    const { data, error } = await request;
    if (error) return res.status(500).json({ error: "Provider search failed." });
    res.json({ query: q, providerId, playbackEnabled: playbackIds.includes(providerId), movies: data ?? [] });
  } catch {
    res.status(500).json({ error: "Provider search failed." });
  }
});

app.get("/api/movie/:id/search", async (req, res) => {
  if (!supabase) return res.status(503).json({ error: "Supabase server configuration missing." });
  try {
    const movie = await movieById(req.params.id);
    if (!movie) return res.status(404).json({ error: "Movie not found." });
    const providers = await providerIds();
    const playbackProviders = await playbackProviderIds();
    const sourceAllowed = !!movie.source_id && providers.includes(String(movie.source_id));
    const playbackAllowed = !!movie.source_id && playbackProviders.includes(String(movie.source_id));
    if (!sourceAllowed || !playbackAllowed || !movie.watch_url || !(await safeUrl(String(movie.watch_url)))) {
      return res.json({ movieId: movie.id, providersChecked: providers.length, sources: [] });
    }
    const health = await checkSource(String(movie.watch_url));
    const finalUrl = health.finalUrl ?? String(movie.watch_url);
    res.json({ movieId: movie.id, providersChecked: providers.length, playbackProvidersChecked: playbackProviders.length, sources: health.ok ? [{ providerId: movie.source_id, kind: playbackKind(finalUrl, health.contentType), quality: movie.quality, language: movie.language, health }] : [] });
  } catch { res.status(500).json({ error: "Provider source search failed." }); }
});

app.get("/api/movie/:id/sources", async (req, res) => {
  if (!supabase) return res.status(503).json({ error: "Supabase server configuration missing." });
  try {
    const movie = await movieById(req.params.id);
    if (!movie) return res.status(404).json({ error: "Movie not found." });
    const url = movie.watch_url as string | null;
    if (!(await isPlaybackProviderAllowed(movie.source_id)) || !url || !(await safeUrl(url))) {
      return res.json({ movieId: movie.id, title: movie.title, sources: [] });
    }
    const health = await checkSource(url);
    const finalUrl = health.finalUrl ?? url;
    res.json({ movieId: movie.id, title: movie.title, sources: health.ok ? [{ playbackUrl: proxyUrl(`${req.protocol}://${req.get("host")}`, finalUrl), kind: playbackKind(finalUrl, health.contentType), quality: movie.quality, language: movie.language, health }] : [] });
  } catch { res.status(500).json({ error: "Source lookup failed." }); }
});

app.get("/api/movie/:id/playback", async (req, res) => {
  if (!supabase) return res.status(503).json({ error: "Supabase server configuration missing." });
  try {
    const movie = await movieById(req.params.id);
    if (!movie) return res.status(404).json({ error: "Movie not found." });
    const url = movie.watch_url as string | null;
    if (!(await isPlaybackProviderAllowed(movie.source_id)) || !url || !(await safeUrl(url))) {
      return res.status(403).json({ error: "No approved playback source." });
    }
    const health = await checkSource(url);
    if (!health.ok) return res.status(502).json({ error: health.error ?? "Playback source unavailable.", health });
    const finalUrl = health.finalUrl ?? url;
    res.json({ movieId: movie.id, title: movie.title, source: { playbackUrl: proxyUrl(`${req.protocol}://${req.get("host")}`, finalUrl), kind: playbackKind(finalUrl, health.contentType), quality: movie.quality, language: movie.language, health } });
  } catch { res.status(500).json({ error: "Playback lookup failed." }); }
});

app.get("/api/stream/proxy", async (req, res) => {
  const token = String(req.query.token ?? "");
  const raw = readProxyTarget(token);
  if (!raw || !(await safeUrl(raw))) return res.status(403).json({ error: "Invalid or expired playback token." });
  try {
    const headers: Record<string, string> = {};
    if (req.headers.range) headers.Range = req.headers.range;
    const result = await fetchApproved(raw, { headers, signal: AbortSignal.timeout(15000) });
    const upstream = result.response;
    const finalUrl = result.url;
    if (!(await safeUrl(finalUrl))) return res.status(502).json({ error: "Upstream redirected to a non-approved host." });
    if ((!upstream.ok && upstream.status !== 206) || !upstream.body) return res.status(502).json({ error: "Upstream stream unavailable." });
    const contentType = upstream.headers.get("content-type")?.split(";", 1)[0].trim().toLowerCase() ?? "";
    const isHls = contentType.includes("mpegurl") || finalUrl.split("?", 1)[0].toLowerCase().endsWith(".m3u8");
    res.status(upstream.status);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Accept-Ranges", upstream.headers.get("accept-ranges") ?? "bytes");
    if (isHls) {
      const buffer = await upstream.arrayBuffer();
      if (buffer.byteLength > MAX_HLS_MANIFEST_BYTES) return res.status(502).json({ error: "HLS manifest is too large." });
      const rewritten = rewriteHlsManifest(Buffer.from(buffer).toString("utf8"), finalUrl, `${req.protocol}://${req.get("host")}`);
      res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
      res.setHeader("Content-Length", Buffer.byteLength(rewritten));
      return res.end(rewritten);
    }
    for (const name of ["content-type", "content-length", "content-range"]) {
      const value = upstream.headers.get(name);
      if (value) res.setHeader(name, value);
    }
    const reader = upstream.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!res.write(Buffer.from(value))) await new Promise<void>((resolve) => res.once("drain", resolve));
    }
    res.end();
  } catch (error) {
    if (!res.headersSent) res.status(502).json({ error: error instanceof Error ? error.message : "Proxy failed." });
    else res.end();
  }
});

app.use((_, res) => res.status(404).json({ error: "Not found." }));
app.use((err: unknown, _, res: express.Response, __: express.NextFunction) => res.status(400).json({ error: err instanceof Error ? err.message : "Bad request." }));

app.listen(port, () => console.log(`Movie Search API listening on :${port}`));
