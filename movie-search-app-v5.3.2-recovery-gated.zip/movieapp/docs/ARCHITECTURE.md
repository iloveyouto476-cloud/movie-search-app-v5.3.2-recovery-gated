# Architecture mapping — v5.3.2 hardened

## 1. Frontend (Client)
React + TypeScript + Vite + React Router.

- Search page
- Movie detail page
- Internal HTML5 player
- Bookmarks / history / settings in localStorage
- Browser talks to Backend API only

## 2. Backend API (Server)
Node.js + Express + TypeScript.

Endpoints:
- `GET /api/health`
- `GET /api/config`
- `GET /api/providers`
- `GET /api/providers/:id/search?q=...`
- `GET /api/search?q=...`
- `GET /api/movie/:id`
- `GET /api/movie/:id/search`
- `GET /api/movie/:id/sources`
- `GET /api/movie/:id/playback`
- `GET /api/stream/proxy?token=...`

## 3. Provider Manager / Source Aggregator
- Catalog search is restricted to `enabled=true` + `search_enabled=true` providers.
- Provider-scoped search is available at `/api/providers/:id/search`.
- Playback is separately restricted to `enabled=true` + `external_watch_enabled=true` providers.
- Source health checks run before a source is returned as playable.

## 4. Data layer
Supabase is the catalog/provider registry in this implementation.

- `movies` is filtered by `is_safe=true`.
- `movie_sources` is the provider registry.
- Supabase service-role credentials remain server-only.
- Client state uses localStorage for bookmarks/history/settings.

## 5. Stream Proxy Service
- Exact host allowlist
- Blocked-host policy
- Public DNS/private-IP checks
- Redirect revalidation
- Signed short-lived HMAC proxy tokens
- HTTP Range forwarding
- HLS manifest rewriting for child playlists, segments, keys, maps, and subtitles

## 6. Settings & Config
Environment controls backend/API origins, provider allowlists, and proxy signing. Client settings persist locally.

## 7. Video Player
Native HTML5 `<video>` receives only the backend proxy URL. UI status progresses through metadata → canplay → playing → timeupdate.

## 8. How it works
Search → Backend → Provider eligibility → Catalog results → Detail → Source health check → Signed proxy → Player.

## 9. Deployment
The frontend defaults to same-origin `/api`. Vite development proxies `/api` to `http://localhost:3001`; production can place Nginx/reverse proxy in front of the API.

## 10. File structure
```text
movie-search-app/
├─ frontend/
│  ├─ public/
│  └─ src/
│     ├─ services/
│     ├─ types.ts
│     └─ App.tsx
├─ server/
│  └─ src/
│     └─ server.ts
├─ database/
│  └─ recovery-migration.sql
├─ docs/
└─ README.md
```

## Verification caveat
The reference image lists SQLite + memory cache as an architectural option. This repaired baseline uses Supabase as the persistent catalog because that is what the supplied source already implements; it does not pretend SQLite is active when it is not.
