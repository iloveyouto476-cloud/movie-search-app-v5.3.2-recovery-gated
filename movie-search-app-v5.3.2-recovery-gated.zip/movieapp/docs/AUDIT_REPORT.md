# System + Search + Playback Audit — v5.3.2

## TEST → ANALYZE → CHANGE METHOD → RETEST → VERIFY

### TEST / findings

1. The supplied reference expects a provider-manager search flow and a provider-scoped `/api/providers/:id/search` endpoint. The endpoint was absent.
2. Search providers and playback providers were treated too similarly: playback could use a safe movie URL without verifying that its provider was explicitly enabled for external watching.
3. Search pattern escaping omitted `*`, which can act as a wildcard in PostgREST pattern syntax.
4. The frontend defaulted to a hard-coded `http://localhost:3001`, making a same-origin production deployment fragile without an injected environment variable.
5. Audit documentation contained stale statements about a raw `?url=` proxy and frontend Supabase credentials.
6. The ZIP has no package-lock files; dependency-backed build verification therefore cannot be reproduced with `npm ci` from this artifact alone.

### ANALYZE / root causes

- Provider eligibility was not separated by capability.
- The architecture endpoint list and runtime routes had drifted.
- Client deployment assumed a development API origin.
- Documentation had not been synchronized with the hardened proxy implementation.
- The artifact was source-only without registry-resolved lock metadata.

### CHANGE METHOD / repairs

- Added `/api/providers/:providerId/search`.
- Added a playback-provider gate using `enabled=true` + `external_watch_enabled=true`.
- Applied the playback-provider gate to `/api/movie/:id/sources` and `/api/movie/:id/playback`.
- Expanded query escaping to include `%`, `_`, `*`, `(`, `)`, `,`, and backslash.
- Changed frontend API default to same-origin and added Vite `/api` development proxying.
- Synchronized README, architecture, and test documentation with the actual implementation.

### RETEST / results

| Area | Result | Evidence boundary |
|---|---|---|
| Search → Backend API | PASS | code-path inspection |
| Provider-scoped search | PASS | code-path inspection |
| Search provider gate | PASS | code-path inspection |
| Playback provider gate | PASS | code-path inspection |
| Safe movie policy | PASS | `is_safe=true` enforced |
| Host allowlist | PASS | fail-closed static inspection |
| Private IP protection | PASS | static inspection |
| Redirect revalidation | PASS | static inspection |
| Signed proxy token | PASS | static inspection |
| Raw `?url=` proxy bypass | PASS (rejected by design) | endpoint accepts `token` only |
| Range forwarding | PASS | static inspection |
| HLS rewriting | PASS | static inspection |
| Player real-event status | PASS | static inspection |
| Real Supabase query | BLOCKED | credentials/environment absent |
| Real browser decode | NOT VERIFIED | authorized media source absent |
| npm install / production build | BLOCKED | registry access timed out |

### VERIFY boundary

The repaired ZIP is internally consistent by source inspection. Real end-to-end Search → Detail → Health Check → Proxy → browser decode still requires deployment-time credentials and an authorized/licensed media source.
