# TEST → ANALYZE → CHANGE METHOD → RETEST → VERIFY

## Reference architecture coverage

The implementation is checked against the supplied architecture reference:

1. Frontend Client — React + TypeScript, responsive search/detail/player/settings UI.
2. Backend API — Node.js + Express + TypeScript.
3. Providers — provider registry with enabled/search-enabled and playback-enabled policy gates.
4. Data layer — Supabase movie catalog; browser never receives the service-role key.
5. Stream Proxy — signed, short-lived proxy tokens; range forwarding; HLS manifest rewriting.
6. Settings & Config — API/environment configuration plus persistent client settings.
7. Internal Video Player — native HTML5 video with real playback event reporting.
8. Runtime flow — Search → aggregate catalog results → Detail → source health check → Player.
9. Technology stack — Vite + React Router on the client; Express/Supabase on the server.
10. Deployment — same-origin `/api` proxy is supported; Vite dev proxy targets the local backend.
11. File structure — frontend, server, database, and docs are separated as shown by the reference.

## Round 1 — failures found

- Playback routes did not require the movie's `source_id` to belong to a provider explicitly enabled for external playback.
- The reference endpoint `GET /api/providers/:id/search` was missing.
- Search wildcard escaping did not include `*`, allowing unintended pattern expansion in provider/catalog search.
- Frontend defaulted to `localhost:3001`, which breaks a production static deployment when no VITE_API_BASE_URL is injected.
- Documentation contained stale claims about a raw `?url=` proxy and a frontend Supabase key.
- No package-lock.json was included, so reproducible `npm ci` could not be performed from the supplied ZIP.

## ROOT CAUSE → NEW METHOD

1. Separate provider eligibility for catalog search from provider eligibility for playback.
2. Add the provider-scoped search API and keep the shared catalog query behind the backend.
3. Escape `%`, `_`, `*`, `(`, `)`, `,`, and backslash before constructing the PostgREST `or()` filter.
4. Default the frontend API base to same-origin and use Vite's `/api` development proxy.
5. Rewrite documentation to match the actual code path: signed token proxy, no frontend Supabase credentials.
6. Do not fabricate a package-lock without registry metadata; record dependency-install verification as blocked when the registry is unavailable.

## RETEST matrix

| Test | Expected | Result |
|---|---|---|
| Search route | Browser calls backend `/api/search` | PASS by code inspection |
| Provider-scoped search | `/api/providers/:id/search` only accepts search-enabled providers | PASS by code inspection |
| Catalog provider gate | Search uses enabled + search-enabled provider IDs | PASS by code inspection |
| Playback provider gate | Playback requires enabled + external-watch-enabled provider | PASS by code inspection |
| Unsafe movie | `is_safe=true` required | PASS by code inspection |
| Unapproved stream host | rejected | PASS by code inspection |
| Private/link-local IP | rejected | PASS by code inspection |
| Redirect to unapproved host | rejected | PASS by code inspection |
| Raw proxy URL parameter | not accepted | PASS by code inspection |
| Signed token tampering/expiry | rejected | PASS by code inspection |
| MP4/WebM/OGG | range-capable proxy | PASS by code inspection |
| HLS | manifest + URI targets rewritten through signed proxy | PASS by code inspection |
| Player success state | only `playing` marks real playback | PASS by code inspection |
| Search/detail/playback real API | requires Supabase + approved runtime config | BLOCKED in this environment |
| Browser decoded frame / advancing time | must be observed in a real browser | NOT VERIFIED without authorized media source |
| `npm ci` / production build | requires registry/package metadata | BLOCKED: npm registry timed out |

## Verification boundary

A real end-to-end PASS still requires deployment-time credentials, an approved stream hostname, real movie data, and a browser run. No demo stream or fake provider response is embedded to manufacture a PASS.
