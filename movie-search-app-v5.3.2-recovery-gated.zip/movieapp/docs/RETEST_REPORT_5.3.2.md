# Retest Report — v5.3.2

## QA method
TEST → ANALYZE → CHANGE METHOD → RETEST → VERIFY

On failure: FAIL → ROOT CAUSE → NEW METHOD → RETEST.

## Change applied
- Replaced the hard-coded `blockedHosts` set with `BLOCKED_STREAM_HOSTS` environment configuration.
- Kept `ALLOWED_STREAM_HOSTS` as the mandatory exact-host allowlist.
- Kept private-IP/SSRF checks, DNS resolution, redirect re-validation, HMAC signed proxy tokens, Range forwarding, HLS manifest rewriting, and same-origin browser proxy isolation.
- Fixed Search → Detail capability consistency: `/api/movie/:id/search` now requires the provider to be enabled for both search and external playback before reporting a playable source.
- Added a deterministic static security regression test at `tests/security-regression.mjs`.
- Cleaned transient `node_modules`/build artifacts from the release archive after verification attempts.

## Retest matrix

| Gate | Result | Evidence |
|---|---|---|
| Search | PASS (static) | Search uses enabled/search-enabled providers and safe movies. |
| Detail | PASS (static) | Movie lookup requires `is_safe=true`; source check follows the unified playback capability. |
| Source Health | PASS (static) | Health check uses the same approved URL and redirect policy. |
| Playback | PASS (static) | Playback requires `external_watch_enabled`, approved host, and healthy media. |
| playing | BLOCKED | Real browser/media playback requires installed dependencies + runtime configuration. |
| Security Regression | PASS (static) | `tests/security-regression.mjs` passed; hard-coded five-host set is absent. |
| Production Build | BLOCKED | npm dependency installation timed out in the environment; therefore build cannot honestly be marked PASS. |
| Browser Verify | BLOCKED | No runnable frontend/server environment was available after dependency installation timeout. |

## Production verification boundary
A real runtime PASS still requires:
1. Successful dependency installation and a generated `package-lock.json`.
2. `npm run typecheck` and production `npm run build` passing for both server and frontend.
3. Valid Supabase configuration and test data.
4. An explicitly authorized/licensed/public-domain stream host configured in `ALLOWED_STREAM_HOSTS`.
5. Browser verification of Search → Detail → Source Health → Playback → `playing` → advancing `currentTime`.

## Security note
Removing the hard-coded deny list does **not** make arbitrary hosts playable. A host must still be explicitly allowlisted and must pass URL protocol/port validation, DNS public-IP validation, redirect re-validation, and signed proxy checks. Keep `BLOCKED_STREAM_HOSTS` populated when an explicit deny policy is required.

## Release decision
**NOT READY — HOLD** until dependency-backed build and real browser/runtime verification pass.
