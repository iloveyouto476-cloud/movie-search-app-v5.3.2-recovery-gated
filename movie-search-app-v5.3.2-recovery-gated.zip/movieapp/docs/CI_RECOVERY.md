# CI Recovery Gate

This repository intentionally does not fabricate `package-lock.json` files. The release archive has package manifests but no lockfiles, while the current execution environment cannot resolve `registry.npmjs.org`.

The GitHub Actions workflow in `.github/workflows/recovery-gates.yml` is the recovery path:

1. Run on a network-enabled runner.
2. Require an existing `package-lock.json`.
3. Run `npm ci`.
4. Run typecheck and production build for both frontend and server.
5. Run the static security regression suite.

A lockfile must be generated from the exact committed `package.json` manifests in a network-enabled environment and committed before the `npm ci` gate can pass. `npm ci` requires an existing lockfile and will not update it. See npm documentation: https://docs.npmjs.com/cli/commands/npm-ci/
