# Source Health Check + Real Playback Verification — v5.3.2

## TEST → ANALYZE → CHANGE METHOD → RETEST → VERIFY

### 1. Source policy audit

- Movie rows are accepted only when `is_safe=true`.
- Playback requires `source_id` to belong to an enabled provider with `external_watch_enabled=true`.
- The source hostname must be explicitly present in `ALLOWED_STREAM_HOSTS`.
- Private/link-local/loopback and other non-public addresses are rejected after DNS resolution.
- Blocked provider hosts remain denied.
- Redirect destinations are manually followed and revalidated against the same policy.

**Result: PASS by static code-path inspection.**

### 2. Player → Proxy path

1. Browser searches through `/api/search`.
2. Detail loads through `/api/movie/:id`.
3. Detail asks `/api/movie/:id/search` for a health-checked playable source.
4. Player asks `/api/movie/:id/playback`.
5. Backend checks movie safety, provider playback eligibility, URL policy, and source health.
6. Backend returns only a same-origin signed proxy URL to the browser.
7. Direct media forwards browser Range requests through the proxy.
8. HLS manifests are rewritten so child playlists, segments, keys, maps, subtitles, and URI attributes also use short-lived signed proxy URLs.
9. The player marks actual playback only after the browser emits `playing`; `timeupdate` confirms progress.

**Result: PASS by static code-path inspection.**

### 3. Security negative tests

| Test | Expected | Result |
|---|---|---|
| Missing token | 403 | PASS by code inspection |
| Tampered token | 403 | PASS by code inspection |
| Expired token | 403 | PASS by code inspection |
| Raw `?url=` proxy parameter | rejected | PASS by code inspection |
| Unapproved host | rejected | PASS by code inspection |
| Blocked host | rejected | PASS by code inspection |
| Private IP | rejected | PASS by code inspection |
| Redirect to unapproved host | rejected | PASS by code inspection |
| Movie provider not enabled for playback | 403 / empty sources | PASS by code inspection |
| Unsafe movie | not returned / not playable | PASS by code inspection |

### 4. Real playback verification boundary

A real browser playback PASS cannot be honestly claimed from this source-only artifact. It requires:

1. Install the declared npm dependencies successfully.
2. Configure valid Supabase server credentials.
3. Configure an exact, authorized/licensed/public-domain host in `ALLOWED_STREAM_HOSTS`.
4. Have a real `movies` row with `is_safe=true`, a matching enabled `movie_sources` row, `external_watch_enabled=true`, and a valid `watch_url`.
5. Start API + frontend.
6. Verify Search → Detail → Source Health → signed Proxy → `loadedmetadata` → `canplay` → `playing` → advancing `currentTime` in a real browser.

The build environment used for this repair could not complete npm registry access before timeout, so dependency-backed Vite/TypeScript execution remains **BLOCKED**, not falsely marked PASS.
