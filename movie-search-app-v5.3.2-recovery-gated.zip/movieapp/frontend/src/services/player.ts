export type PlaybackSource = {
  playbackUrl: string;
  kind: "hls" | "video";
  quality?: string | null;
  language?: string | null;
  health: { ok: boolean; status?: number; contentType?: string; finalUrl?: string; error?: string };
};

const API_BASE = (import.meta.env.VITE_API_BASE_URL ?? "").replace(/\/$/, "");

export async function getPlaybackSource(movieId: string): Promise<PlaybackSource> {
  const response = await fetch(`${API_BASE}/api/movie/${encodeURIComponent(movieId)}/playback`);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error ?? "Playback source unavailable.");
  return body.source as PlaybackSource;
}
