import type { Movie, Provider } from "../types";

const API_BASE = (import.meta.env.VITE_API_BASE_URL ?? "").replace(/\/$/, "");

async function api<T>(path: string): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error ?? "Request failed.");
  return body as T;
}

export async function searchMovies(query: string): Promise<Movie[]> {
  const body = await api<{ movies: Movie[] }>(`/api/search?q=${encodeURIComponent(query.trim())}`);
  return body.movies ?? [];
}

export async function getMovie(id: string): Promise<Movie> {
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(id)) throw new Error("Movie not found.");
  return api<Movie>(`/api/movie/${encodeURIComponent(id)}`);
}

export async function getProviders(): Promise<Provider[]> {
  return api<Provider[]>("/api/providers");
}

export async function searchMovieSources(id: string) {
  return api<{ movieId: string; providersChecked: number; sources: Array<{ providerId?: string | null; kind: "hls" | "video"; quality?: string | null; language?: string | null; health: { ok: boolean; status?: number; contentType?: string; finalUrl?: string; error?: string } }> }>(`/api/movie/${encodeURIComponent(id)}/search`);
}
