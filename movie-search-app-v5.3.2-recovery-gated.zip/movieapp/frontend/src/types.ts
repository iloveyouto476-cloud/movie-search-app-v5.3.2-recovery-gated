export type Movie = {
  id: string;
  title: string;
  original_title?: string | null;
  year?: number | null;
  rating?: number | null;
  duration?: string | null;
  genre?: string[] | null;
  director?: string | null;
  cast_members?: string[] | null;
  plot?: string | null;
  poster?: string | null;
  backdrop?: string | null;
  trailer_url?: string | null;
  source_id?: string | null;
  quality?: string | null;
  language?: string | null;
  subtitles?: string[] | null;
  is_safe?: boolean | null;
  external_open?: boolean | null;
};

export type Provider = {
  id: string;
  name: string;
  enabled: boolean;
  status: string;
  priority: number;
  trust_score: number;
  search_enabled: boolean;
  metadata_import_enabled: boolean;
  external_watch_enabled: boolean;
  iframe_enabled: boolean;
};

export type WatchSource = {
  id: string;
  label: string;
  type: "video" | "embed";
  quality?: string | null;
  language?: string | null;
  allowed: boolean;
};
