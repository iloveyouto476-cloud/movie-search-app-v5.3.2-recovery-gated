-- Non-destructive recovery hardening for the existing Supabase schema.
-- Existing movie_sources is a provider registry, so do not replace it.

alter table public.movies enable row level security;
alter table public.movie_sources enable row level security;

drop policy if exists movies_safe_public_read on public.movies;
create policy movies_safe_public_read
on public.movies for select
to anon, authenticated
using (coalesce(is_safe, false) = true);

drop policy if exists provider_public_read on public.movie_sources;
create policy provider_public_read
on public.movie_sources for select
to anon, authenticated
using (enabled = true);

create index if not exists movies_title_search_idx
on public.movies using gin (
  to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(original_title,''))
);

-- Safety state for the five user-requested domains:
-- They are retained as provider records but are NOT approved for playback.
update public.movie_sources
set
  status = 'pending_review',
  external_watch_enabled = false,
  iframe_enabled = false,
  metadata_import_enabled = false,
  updated_at = now()
where lower(regexp_replace(url, '^https?://(www\\.)?', '')) like 'hd432.com%'
   or lower(regexp_replace(url, '^https?://(www\\.)?', '')) like 'dunung24.com%'
   or lower(regexp_replace(url, '^https?://(www\\.)?', '')) like '037hddmovies.com%'
   or lower(regexp_replace(url, '^https?://(www\\.)?', '')) like '24kfree.com%'
   or lower(regexp_replace(url, '^https?://(www\\.)?', '')) like 'movie22thai.com%';
