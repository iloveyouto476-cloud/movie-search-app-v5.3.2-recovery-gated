import fs from 'node:fs';
import assert from 'node:assert/strict';

const server = fs.readFileSync(new URL('../server/src/server.ts', import.meta.url), 'utf8');
const env = fs.readFileSync(new URL('../server/.env.example', import.meta.url), 'utf8');

assert.match(server, /process\.env\.BLOCKED_STREAM_HOSTS/);
assert.doesNotMatch(server, /new Set\(\[\"hd432\.com\"/);
assert.doesNotMatch(server, /new Set\(\[\"dunung24\.com\"/);
assert.doesNotMatch(server, /new Set\(\[\"037hddmovies\.com\"/);
assert.doesNotMatch(server, /new Set\(\[\"24kfree\.com\"/);
assert.doesNotMatch(server, /new Set\(\[\"movie22thai\.com\"/);
assert.match(env, /^BLOCKED_STREAM_HOSTS=/m);
assert.match(server, /const playbackProviders = await playbackProviderIds\(\);/);
assert.match(server, /const playbackAllowed = !!movie\.source_id && playbackProviders\.includes/);
assert.match(server, /!sourceAllowed \|\| !playbackAllowed/);

function normalizeHost(value) {
  return value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/$/, '').replace(/^www\./, '');
}
function parseList(value) {
  return new Set((value ?? '').split(',').map(normalizeHost).filter(Boolean));
}

const blocked = parseList('');
assert.equal(blocked.size, 0);
const configured = parseList('Example.com, https://WWW.Example2.com/');
assert.deepEqual([...configured].sort(), ['example.com', 'example2.com']);

console.log('Security regression static checks: PASS');
