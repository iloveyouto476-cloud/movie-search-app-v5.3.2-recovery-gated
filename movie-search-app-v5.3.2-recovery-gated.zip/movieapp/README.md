# Movie Search App — v5.3.2 Hardened

Repaired against the supplied **SYSTEM ARCHITECTURE** reference and validated using:

`TEST → ANALYZE → CHANGE METHOD → RETEST → VERIFY`

Failures follow:

`FAIL → ROOT CAUSE → NEW METHOD → RETEST`

## Runtime architecture

`Frontend → Backend API → Provider Manager → Supabase Catalog → Detail → Source Health Check → Signed Stream Proxy → Internal Player`

## Repairs in this build

- Search stays behind the Backend API; the browser does not query Supabase directly.
- Added `GET /api/providers/:id/search?q=` for provider-scoped search.
- Catalog search is limited to enabled + search-enabled providers.
- Playback/source lookup now also requires the movie `source_id` to belong to an enabled + external-watch-enabled provider.
- Search pattern input escapes SQL/PostgREST wildcard characters including `*`, `%`, and `_`.
- Playback uses short-lived HMAC-signed proxy tokens; raw upstream URLs are not accepted by the proxy endpoint.
- Every proxy request rechecks the host allowlist, DNS/private-IP policy, and redirect destination.
- MP4/WebM/OGG-style direct media forwards Range requests.
- HLS manifests are rewritten so child playlists, segments, keys, maps, and subtitles return through the signed proxy.
- Player UI reports actual browser media events (`loadedmetadata`, `canplay`, `playing`, `timeupdate`).
- Bookmarks, history, and settings persist in localStorage.
- Frontend API defaults to same-origin `/api`; Vite proxies `/api` to the local backend during development.
- No demo movie, fake stream, secret, or unapproved provider is embedded.

## Environment

### Backend

```text
PORT=3001
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_ROLE_KEY=DO_NOT_PUT_THIS_IN_FRONTEND
ALLOWED_STREAM_HOSTS=
ALLOWED_ORIGINS=http://localhost:5173
PROXY_SIGNING_SECRET=CHANGE_ME_TO_A_LONG_RANDOM_SECRET
```

### Frontend

`VITE_API_BASE_URL` is optional. Leave it empty when frontend and API share the same origin/reverse proxy.

## Run

```bash
cd server
npm install
cp .env.example .env
npm run dev
```

In another terminal:

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

## Database

Apply `database/recovery-migration.sql` to the existing Supabase project. It enables safe-read policies, creates the title-search index, and disables external playback/import for the five previously flagged provider domains.

## Verification status

Static/code-path verification of search, provider gating, source health, signed proxy behavior, Range handling, HLS rewriting, and player event flow is complete.

A full `npm ci`/production build and real playback decode cannot be marked PASS in the supplied environment because package installation timed out and the ZIP contains no real Supabase credentials or authorized playback host. No fake PASS is reported.
